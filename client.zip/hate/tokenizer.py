from hate import config


tokenizer = config.tokenizer_type.from_pretrained(config.pretrained_name)